package src.components.components.datastructures.list;

import src.components.components.datastructures.AbstractPanelDataStructureNode;

public abstract class AbstractPanelListNode extends AbstractPanelDataStructureNode {
    public AbstractPanelListNode(int index, int value, int width, int height) {
        super(index, value, width, height);
    }
}
