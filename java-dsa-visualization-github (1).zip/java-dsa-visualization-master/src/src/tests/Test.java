package src.tests;

public interface Test {
    void run();
}
